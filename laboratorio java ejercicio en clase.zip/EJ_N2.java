import java.util.Scanner;

public class EJ_N1 {
    public static void main(String[] args) {
        Scanner op=new Scanner(System.in);

  System.out.println("ingresa un numero");
  int nm=op.nextInt();
     
     if(nm>=0){
       System.out.println("El numero "+nm+" es positivo");

     if(nm<=100){
        System.out.println("El numero esta en el rango de 0 a 100");
     }else{
        System.out.println("El numero es mayor de 100");
     }
     }else{
        System.out.println("El numero "+nm+" no es positivo");
     }
  
    
    
    
    }
    }