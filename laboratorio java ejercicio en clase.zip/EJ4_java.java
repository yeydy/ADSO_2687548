import java.util.Scanner;

public class EJ_java {
    public static void main(String[] args) {
        Scanner op=new Scanner(System.in);
    int n,c,variabl,s;
    System.out.println("ingrese la operacion que desea realizar");
    variabl=op.nextInt();



    switch(variabl){
        case 1:
                System.out.println("Ingrese un para hacer la tabla de multiplicar ");
                 n=op.nextInt();
                for( c=1;c<=10;c++){
                 System.out.println(n+" x "+c+" = "+n*c);
                 }
        break;

        case 2:
                System.out.println("Ingrese un numero hacer la tabla de sumar ");
                 s=op.nextInt();
                for( c=1;c<=10;c++){
                 System.out.println(s+" + "+c+" = "+(s+c));
                 }      
        break;
       default:
                System.out.println("El numero"+variabl+"NO esta dentro del rango de 1 y 2");
        break;


}
    }
}
