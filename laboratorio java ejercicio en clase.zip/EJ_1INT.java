import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class EJ_1INT
{
public static void main (String args[])throws IOException
{
BufferedReader in;
in = new BufferedReader (new InputStreamReader (System.in));
int n;
System.out.println("Ingrese el numero a verificar: ");
n = Integer.parseInt(in.readLine());
if(n>=80&n<=100)
System.out.println("El numero se encuentra en el intervalo cerrado [80-100]");
else
System.out.println("El numero no se encuentra en el intervalo cerrado [80-100]");
}}