public class EJ3 {
    public static void main(String[] args) {
        int lit = 10;
        int i; 
        for ( i=1; i<=lit; i++);{

            for (int j=1; j<=i; j++);
              System.out.print("*");
        }
        System.out.println();
    }
}
