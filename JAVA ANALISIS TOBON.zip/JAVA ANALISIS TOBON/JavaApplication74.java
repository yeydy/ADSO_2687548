
package javaapplication74;


public class JavaApplication74 {


    public static void main(String[] args) {
      int Mensual = 2000;
        int Minimo = 1200;

        if (Mensual > Minimo) {
            System.out.println("El valor es mayor" + Mensual);
        } else {
            System.out.println("El valor es menor" + Minimo);

        }
    }
    
}
