package javaapplication74;

public class minimo {

    public static void main(String[] args) {

        int c = 522;

        if (c % 2 == 0) {
            System.out.println("El valor es par " + c);
        } else {
            System.out.println("El valor es impar " + c);

        }
    }
