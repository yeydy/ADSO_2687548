import java.util.Scanner;
public class primero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número: ");
        double numero = scanner.nextDouble();
        if (numero > 0) {
            if (numero > 60 && numero < 90) {
                System.out.println("El número está dentro del intervalo abierto (60, 90).");
            } else {
                System.out.println(" El número es positivo pero no se encuentra dentro del intervalo abierto (60, 90).");
            }
        } else {
            System.out.println(" El número no es positivo.");
        }
    }
}

