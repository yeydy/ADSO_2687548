import java.util.Scanner;

public class segundo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int edad = 0;
        int totalEdades = 0;
        int cantidadPersonas = 0;
        int cantidadMayores50 = 0;
        double porcentajeMayores50 = 0.0;
        do {
            System.out.print("Ingrese una edad (0 para terminar): ");
            edad = scanner.nextInt();
            if (edad > 0) {
                totalEdades += edad;
                cantidadPersonas++;
                if (edad > 50) {
                    cantidadMayores50++;
                }
            }
        } while (edad != 0);
        if (cantidadPersonas > 0) {
            double promedioEdades = (double) totalEdades / cantidadPersonas;
            porcentajeMayores50 = (double) cantidadMayores50 / cantidadPersonas * 100.0;
            System.out.printf("El promedio de las edades ingresadas es %.2f\n", promedioEdades);
            System.out.printf("El %.2f%% de las personas ingresadas son mayores a 50 años\n", porcentajeMayores50);
        } else {
            System.out.println("No se ingresaron edades válidas");
        }
    }
}

