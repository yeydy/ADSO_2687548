import java.util.Scanner;

public class segundo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int edad = 0;
        int totalEd = 0;
        int cantidadPer = 0;
        int cantidadMay50 = 0;
        double porcenMayores50 = 0.0;
        do {
            System.out.print("Ingrese una edad: ");
            edad = scanner.nextInt();
            if (edad > 0) {
                totalEd += edad;
                cantidadPer++;
                if (edad > 50) {
                    cantidadMay50++;
                }
            }
        } while (edad != 0);
        if (cantidadPer > 0) {
            double promedioEdades = (double) totalEd / cantidadPer;
            porcenMayores50 = (double) cantidadMay50 / cantidadPer * 100.0;
            System.out.printf("El promedio de las edades ingresadas es %.2f\n", promedioEdades);
            System.out.printf("El %.2f%% de las personas ingresadas son mayores a 50 años\n", porcenMayores50);
        } else {
            System.out.println("No se ingresaron una edad");
        }
    }
}