import java.sql.SQLOutput;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int num;
        System.out.println("ingrese el numero");
        num = leer.nextInt();
        if (num >= 60 && num <= 90 && num > 0) {
            System.out.println("el numero es positivo y esta en el intervalo");
        }
        else {
     System.out.println("error");
        }
    }
}