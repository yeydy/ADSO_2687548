import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
       int  num;
        System.out.println("ingrese un numero");





        }
    }
}