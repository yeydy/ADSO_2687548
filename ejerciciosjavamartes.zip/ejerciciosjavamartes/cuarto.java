import java.util.Scanner;
public class cuarto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número: ");
        int numero = scanner.nextInt();
        int i = 1;
        while (i <= 10) {
            int producto = numero * i;
            System.out.println(numero + " x " + i + " = " + producto);
            i++;
        }
    }
}