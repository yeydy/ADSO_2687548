package javaapplication5;
   import java.util.Scanner;
public class JavaApplication5 {
    
    public static void main(String[] args) {
        
     

 
         Scanner scanner = new Scanner(System.in);
         System.out.println(" ingresa el numero ");
         int num = scanner.nextInt();
         
         
         if (num<0 && num > -80 && num < -100){
             System.out.println(" Eel numero esta en el intervalo abierto 80-100 ");
         }
         else if (num<0){
             System.out.println(" el numero no esta en el intervalo abierto 80-100");
         }
         else{
             System.out.println(" error el numero debe ser negativo ");
                 
                 }
     }
}
     

    
    

