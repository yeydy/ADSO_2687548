
package ejercicio_companero;

public class Ejercicio_companero{

   
    public static void main(String[] args) {
        float SueldoActual=1000000;
        float SueldoMinimo=950000;
        
        if(SueldoActual>SueldoMinimo){
            System.out.println("el sueldo actual es mayor");
        }
        else{
            System.out.println("el sueldo actual no es mayor al minimo");
        }
        
    }
    
}
