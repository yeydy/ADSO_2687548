
package ejercicio_par_impar;

public class Ejercicio_par_impar {
    public static void main(String[] args) {
       int c=7;
       if(c%2==0){
           System.out.println("el numero " + c + " es par");
       }
       else{
           System.out.println("el numero " + c + " es impar"); 
       }
    }
    
}
