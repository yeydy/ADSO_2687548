
package ejercicio2;

public class Ejercicio2 {

    
    public static void main(String[] args) {
 int C=10;     
         if (C%2==0){
        System.out.println("el numero " +C+ " es par ");
    }
         else {
             System.out.println(" el numero " +C+ " es impar ");
         }
    }
}
