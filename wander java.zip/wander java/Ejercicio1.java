
package ejercicio1;


public class Ejercicio1 {

  
    public static void main(String[] args) {
int Sa=3000000;
int Sm=1000000;
if (Sa>Sm){
    System.out.println("el sueldo actual es mayor al minimo");
}
else{
    System.out.println("el sueldo actual es menor al minimo");
}
    }
    
    
}
