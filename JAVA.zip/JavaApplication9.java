
package javaapplication9;
import java.util.Scanner;

public class JavaApplication9 {

    
    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un número entero: ");
        int numero = scanner.nextInt();

        if (numero > 0) {
            System.out.println("El número es positivo.");
        } else {
            System.out.println("El número es negativo o cero.");
        }

        if (numero > 100) {
            System.out.println("El número es mayor a 100.");
        } else {
            System.out.println("El número no es mayor a 100.");
        }
    }
}
