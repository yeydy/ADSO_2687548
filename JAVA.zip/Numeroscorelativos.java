
package numeroscorelativos;

import java.util.Scanner;

public class Numeroscorelativos {

    
    public static void main(String[] args) {
      Scanner Sc = new Scanner(System.in);
        int n = 100; // Valor de n
        int y = 3; // Valor de y
        
        for (int i = 1; i <= n; i++) {
            if (i % y == 0) {
                System.out.println("*");
            } else {
                System.out.println(i);
            }
        }
    }
}
   