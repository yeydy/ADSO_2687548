import java.util.Scanner;
public class ejer3_clase { 
 public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int n,y,x;
    System.out.println("Ingrese un numero para la serie");
    n=sc.nextInt();
    System.out.println("Ingrese un numero multiplo");
    y=sc.nextInt();
    for (x=1;n>=x;x++)
    {
    if (x%y==0)
      System.out.println(" * " + " ");
    else
      System.out.println(x + " ");
    }
  }
}