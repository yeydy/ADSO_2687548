import java.util.Scanner;
public class ejer1_clase {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        int num;
        System.out.println("Ingrese un numero");
        num=leer.nextInt();
        if (num>0){
            System.out.println("El numero es positivo");
        }else {
            if (num<=-80 && num>=-100) {
                System.out.println(" El numero se encuentra en el intervalo 80 - 100 ");
            }else{
                System.out.println(" Error ");
            }
        }
    }
}