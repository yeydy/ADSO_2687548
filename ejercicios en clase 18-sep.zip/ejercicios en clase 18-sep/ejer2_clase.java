import java.util.Scanner;
public class ejer2_clase {
    public static void main(String[] args) {
        Scanner leer=new Scanner(System.in);
        int num;
        System.out.println("Ingrese un numero");
        num=leer.nextInt();
        if (num<0){
            System.out.println("Error");
        }else {
            if (num>100) {
                System.out.println(" El numero es superior a 100 ");
            }else{
                System.out.println(" El numero es positivo ");
            }
        }
    }
}