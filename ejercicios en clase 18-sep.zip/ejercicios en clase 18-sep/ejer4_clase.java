import java.util.Scanner;
public class ejer4_clase { 
 public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int n,x=1;
    System.out.println("Ingrese un numero para la tabla de multiplicar");
    n=sc.nextInt();

    {for(x=1;10>=x;x++)
     System.out.println(n+" * "+x+" = "+n*x);
    }
    System.out.println("-----------------------------------");

    while(10>=x)
    {
     System.out.println(n+" * "+x+" = "+n*x);
     x++;
    }
    System.out.println("-----------------------------------");

    do
    {
        System.out.println(n+" * "+x+" = "+n*x);
        x++;
    }
    while(10>=x);

 }
}