import java.util.Scanner;
public class whileTabla {
    public static void main(String[] args) {
        Scanner table = new Scanner(System.in);
        int number;
        int resultado;
        int x = 0 ;
        System.out.println("digite el numero: ");
        number = table.nextInt();

        while (x<11) {
            resultado = number * x;
            System.out.println(resultado);
            x = x + 1 ;
        }
        table.close();
    }
}
