import java.util.Scanner;
public class edades {
    public static void main(String[] args) {
        Scanner calcular = new Scanner(System.in);
        int z = 1;
        int contador = 0;
        int cantidad = 0;
        int porcentaje= 0;
        int digitos = 0;
        int mayor = 0;
        double promedio;

        do {
            System.out.println("digite la edad a comparar:");
            int ages = calcular.nextInt();
            contador = ages + contador;
            z = ages;
            if (ages > 50) {
                cantidad = ages + cantidad;
                mayor = mayor + 1;
                porcentaje = cantidad/mayor;
            }
            digitos = digitos + 1;
            promedio = (double) contador/digitos;
        } while (z > 0);

        System.out.println("ya terminaste de ingresar edades.");

        System.out.println("el promedio de las edades ingresadas es:" + " " + promedio);
        System.out.println("el porcentaje de las personas mayores a 50 años es:" + " " + porcentaje);
        calcular.close();
    }
}