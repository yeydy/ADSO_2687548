import java.util.Scanner;
public class forTabla {
    public static void main(String[] args) {
        Scanner table = new Scanner(System.in);
        int number;
        int resultado;
        System.out.println("digite el numero: ");
        number = table.nextInt();

            for (int z = 0; z < 11; z++) {
                resultado = number * z;
                System.out.println(resultado);
                table.close();
            }
            table.close();
    }
}
