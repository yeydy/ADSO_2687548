import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner leyendo = new Scanner(System.in);
        int number ;

        System.out.println("digite el numero: ");
        number = leyendo.nextInt();

        if (number>0) {
            if (number>=60 && number<=90) {
                System.out.println("el numero digitado que es" + " "  + number + " " + "es positivo y se encuentra en el rango entre 60 y 90");
            } else {
                System.out.println("el numero no esta en el rango dado");
            }
        } else {
            System.out.println("el numero no es un numero positivo:");
        }
        leyendo.close();
        }
    }