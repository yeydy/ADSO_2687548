import java.util.Scanner;
public class dowhileTabla {
    public static void main(String[] args) {
        Scanner table = new Scanner(System.in);
        int number;
        int resultado;
        int y = 0;
        System.out.println("digite el numero: ");
        number = table.nextInt();

        do {
            resultado = number * y;
            System.out.println(resultado);
            y = y + 1;
        } while (y < 11) ;
        table.close();
    }
}
