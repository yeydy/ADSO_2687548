import java.util.Scanner;
import java.time.Year;
public class añoBisiesto {
    public static void main(String[] args) {
        Scanner year = new Scanner(System.in);

        System.out.println("digita el año a comparar:");
        long año = year.nextLong();

        if (Year.isLeap(año)) {
            System.out.println("El año " + " " + año + " " + " es bisiesto");
        } else {
            System.out.println("El año " + " " + año + " " + " no es bisiesto");
        }
        year.close();
    }
}
